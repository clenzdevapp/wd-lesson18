#!/usr/bin/env python
import os
import time
import jinja2
import webapp2


template_dir = os.path.join(os.path.dirname(__file__), "templates")
jinja_env = jinja2.Environment(loader=jinja2.FileSystemLoader(template_dir), autoescape=False)

# BILD FEHLEND
class Country(object):
    def __init__(self, name, capital):
        self.name = name
        self.capital = capital

class BaseHandler(webapp2.RequestHandler):

    def write(self, *a, **kw):
        return self.response.out.write(*a, **kw)

    def render_str(self, template, **params):
        t = jinja_env.get_template(template)
        return t.render(params)

    def render(self, template, **kw):
        return self.write(self.render_str(template, **kw))

    def render_template(self, view_filename, params=None):
        if params is None:
            params = {}
        template = jinja_env.get_template(view_filename)
        return self.response.out.write(template.render(params))

# RANDOM FEHLEND
country = Country("Frankreich", "Paris")

class MainHandler(BaseHandler):
    # EINGABE
    def get(self):
        question = "Wie lautet die Hauptstadt von " + country.name + " ?"
        params = {"question" : question}
        return self.render_template("quiz.html", params=params)

class ResultHandler(BaseHandler):
    # CHECK
    def post(self):
        result = self.request.get("capital")
        if str(result).capitalize() == country.capital:
            return self.write(str(result).capitalize() + " ist die korrekte Hauptstadt zu " + country.name)
        else:
            return self.write(str(result).capitalize() + " ist nicht die korrekte Hauptstadt zu " + country.name)

app = webapp2.WSGIApplication([
    webapp2.Route('/', MainHandler),
    webapp2.Route('/result', ResultHandler),
], debug=True)
